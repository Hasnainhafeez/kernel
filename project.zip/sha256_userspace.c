#include <openssl/sha.h>
#include <stdio.h>
#include <string.h>

int main() {
    const char *input = "Hello, User Space!";
    unsigned char output[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;

    SHA256_Init(&sha256);
    SHA256_Update(&sha256, input, strlen(input));
    SHA256_Final(output, &sha256);

    printf("SHA-256 hash: ");
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
        printf("%02x", output[i]);
    printf("\n");

    return 0;
}
