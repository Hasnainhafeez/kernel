#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/evp.h>
#include <sys/time.h>

int main() {
    char input[] = "Hello, World!";
    unsigned char output[EVP_MAX_MD_SIZE];
    unsigned int output_len;

    struct timeval start_time, end_time;

    // Get time before hashing
    gettimeofday(&start_time, NULL);

    // Create a new context for SHA-256
    EVP_MD_CTX *mdctx = EVP_MD_CTX_new();
    if (mdctx == NULL) {
        printf("Error creating context\n");
        return 1;
    }

    // Initialize the SHA-256 context
    if (1 != EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL)) {
        printf("Error initializing SHA-256\n");
        return 1;
    }

    // Hash the input data
    if (1 != EVP_DigestUpdate(mdctx, input, strlen(input))) {
        printf("Error updating SHA-256\n");
        return 1;
    }

    // Finalize the SHA-256 hash
    if (1 != EVP_DigestFinal_ex(mdctx, output, &output_len)) {
        printf("Error finalizing SHA-256\n");
        return 1;
    }

    // Get time after hashing
    gettimeofday(&end_time, NULL);

    // Calculate the time difference
    double time_taken = (end_time.tv_sec - start_time.tv_sec) + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;

    // Print hash and time taken
    printf("SHA-256: ");
    for (int i = 0; i < output_len; i++) {
        printf("%02x", output[i]);
    }
    printf("\nTime taken: %f seconds\n", time_taken);

    // Cleanup
    EVP_MD_CTX_free(mdctx);

    return 0;
}
