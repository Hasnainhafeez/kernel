#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/syscall.h>
#include <linux/limits.h>
#include <errno.h>

#define sys_SHA256 548 // System call number
#define SHA256_LENGTH 32

int main() {
    const char *input = "Hello, World!";
    size_t input_len = strlen(input);
    char hash[SHA256_LENGTH];
    int ret;

    // Call the custom SHA-256 system call
    ret = syscall(SYS_SHA256, input, input_len, hash);
    if (ret < 0) {
        perror("syscall");
        return ret;
    }

    // Print the hashed output in hex
    printf("SHA-256 Hash: ");
    for (int i = 0; i < SHA256_LENGTH; i++)
        printf("%02x", (unsigned char)hash[i]);
    printf("\n");

    return 0;
}
