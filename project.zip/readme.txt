----Required Tools and Dependencies-------
Install and Update GCC compiler
sudo apt update
sudo apt install build-essential
-----For Kernel Space-------
sudo apt install linux-headers-$(uname -r)
---To Ensure C compiler is installed----
gcc --version
make --version //make sure your gcc compiler and kernel version is compaitable with each other for smooth execution
-----For additional dependencies-----
sudo apt install libssl-dev
-----To compile UserSpace code------
gcc -o sha256_kernel sha256_kernel.c -lcrypto // if issue occuring then remove -lcrypto
---To Compile KernelSpace----
//Ensure that Makefile and your C file is in same directory - only one makefile is allowed in one directory
make //to compile makefile 
sudo insmod sha256_kernel.ko
sudo dmesg | tail //To see kernel logs where SHA256 will be shown

----To Unload Kernel------
sudo rmmod sha256_kernel
------For System Call code -----
Just compile and run the file with argument
gcc -o filename filename.c
----to run the file----
./filename "argument"
----To Analyze the Performance--
Use htop tool to analyze performance , open htop in another terminal to analyze
if htop is not installed then install sudo apt install htop
------Make sure to clean kernel after execution ----
make clean
sudo rmmod sha256_kernel

