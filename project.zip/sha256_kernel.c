#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <crypto/hash.h>
#include <linux/string.h>
#include <linux/slab.h>

static int __init sha256_kernel_init(void) {
    struct crypto_shash *tfm;
    struct shash_desc *desc;
    char *input = "Hello, Kernel!";
    char output[32];  // SHA-256 output size
    int ret;

    tfm = crypto_alloc_shash("sha256", 0, 0);
    if (IS_ERR(tfm)) {
        pr_err("Failed to allocate shash\n");
        return PTR_ERR(tfm);
    }

    desc = kmalloc(sizeof(*desc) + crypto_shash_descsize(tfm), GFP_KERNEL);
    if (!desc) {
        pr_err("Failed to allocate desc\n");
        crypto_free_shash(tfm);
        return -ENOMEM;
    }

    desc->tfm = tfm;

    ret = crypto_shash_digest(desc, input, strlen(input), output);
    if (ret) {
        pr_err("Failed to compute hash\n");
    } else {
        pr_info("SHA-256 hash: ");
        for (int i = 0; i < 32; i++)
            pr_cont("%02x", output[i]);
        pr_cont("\n");
    }

    kfree(desc);
    crypto_free_shash(tfm);
    return ret;
}

static void __exit sha256_kernel_exit(void) {
    pr_info("SHA-256 kernel module unloaded\n");
}

module_init(sha256_kernel_init);
module_exit(sha256_kernel_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Suhaib");
MODULE_DESCRIPTION("SHA-256 Kernel Space Implementation");

