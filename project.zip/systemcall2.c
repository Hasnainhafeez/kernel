#include <sys/socket.h>
#include <linux/if_alg.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <data_to_hash>\n", argv[0]);
        return 1;
    }

    int sock, fd;
    struct sockaddr_alg sa = {
        .salg_family = AF_ALG,
        .salg_type = "hash",
        .salg_name = "sha256"
    };
    char *data = argv[1];
    char hash[32];

    sock = socket(AF_ALG, SOCK_SEQPACKET, 0);
    if (sock == -1) {
        perror("Socket creation failed");
        return 1;
    }

    if (bind(sock, (struct sockaddr *)&sa, sizeof(sa)) == -1) {
        perror("Bind failed");
        close(sock);
        return 1;
    }

    fd = accept(sock, NULL, 0);
    if (fd == -1) {
        perror("Accept failed");
        close(sock);
        return 1;
    }

    if (write(fd, data, strlen(data)) == -1) {
        perror("Write failed");
        close(fd);
        close(sock);
        return 1;
    }

    if (read(fd, hash, sizeof(hash)) == -1) {
        perror("Read failed");
        close(fd);
        close(sock);
        return 1;
    }

    printf("SHA-256: ");
    for (int i = 0; i < 32; i++) printf("%02x", hash[i]);
    printf("\n");

    close(fd);
    close(sock);
    return 0;
}
